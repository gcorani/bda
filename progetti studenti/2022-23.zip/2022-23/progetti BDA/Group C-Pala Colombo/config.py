# File to store the project's paths:
import os
# Path to the project's root directory
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT_DIR, 'data')
GAMES_CSV = os.path.join(DATA, 'games.csv')
GAMES_DETAILS_CSV = os.path.join(DATA, 'games_details.csv')
PLAYERS_CSV = os.path.join(DATA, 'players.csv')
RANKING_CSV = os.path.join(DATA, 'ranking.csv')
TEAMS_CSV = os.path.join(DATA, 'teams.csv')
